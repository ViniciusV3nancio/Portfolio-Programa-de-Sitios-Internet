document.getElementById('timer').innerHTML = timer;

let createNyanCat = setInterval(function(){randomPosition()}, createNyanCatTimer);