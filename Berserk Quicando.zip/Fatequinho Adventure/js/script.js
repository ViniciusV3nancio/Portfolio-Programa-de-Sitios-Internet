
const mario = document.querySelector('.mario');
const cano = document.querySelector('.cano');
const vitoria = document.querySelector('.vitoria');
let score = 0;

const pulo =() => {
    mario.classList.add('pulo');

    setTimeout(() => {
        mario.classList.remove('pulo');
        
    }, 500);

}

let canoCrossed = false;

const loop = setInterval(() => {
    const canoPosition = cano.offsetLeft;
    const marioPosition = +window.getComputedStyle(mario).bottom.replace('px', '');
    

//Condição de DERROTA
    if (canoPosition <= 120 && canoPosition>= 0 && marioPosition < 100) {
        cano.style.animation = 'none';
        cano.style.left = `${canoPosition}px`

        mario.style.animation = 'none';
        mario.style.bottom = `${marioPosition}px`

        mario.src = 'img/perdeu.png';
        mario.style.width = '120px';
        mario.style.marginLeft = '20px';


        setTimeout(() => {
            // cano.style.display = 'none';
            // mario.style.display = 'none';
            vitoria.src = 'img/derrota.png';
            vitoria.style.left = 0;
            vitoria.style.marginTop = '50px';
            vitoria.style.marginLeft = '280px';
            vitoria.style.width = '500px';
        }, 500);
        // alert(`Game OVER`);
        clearInterval(loop);
    }else if (canoPosition < 0 && !canoCrossed) { // Verifique se o cano não foi cruzado ainda
        score++;
        canoCrossed = true; // Marque o cano como cruzado
        document.getElementById('score').textContent = `Pontuação: ${score}`;
        cano.style.animation = 'cano-animation 2s infinite linear';

        //Condição de VITÓRIA
        if(score === 10){
            clearInterval(loop);
            setTimeout(() => {
                vitoria.style.left = 0;
                vitoria.style.marginTop = '50px';
                vitoria.style.marginLeft = '280px';
                vitoria.style.width = '500px';
                cano.style.display = 'none';
                // mario.style.display = 'none';
            }, 500);
        }
    } else if (canoPosition > 120) {
        canoCrossed = false; // Reinicie a marcação quando o cano sair da tela
    }
}, 10)

document.addEventListener('keydown' , pulo);